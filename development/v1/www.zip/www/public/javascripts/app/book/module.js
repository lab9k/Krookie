var bookModule = angular.module("bookModule", []);
var filterModule = angular.module("filterModule", []);